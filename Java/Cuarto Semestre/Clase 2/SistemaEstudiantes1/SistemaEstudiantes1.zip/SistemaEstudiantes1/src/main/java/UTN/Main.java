package UTN;
import UTN.Conexion.conexion;
public class Main {
    public static void main(String[] args) {
        var conexion = conexion.getConnection();
        if (conexion != null)
            System.out.println("conecion exitosa" + conexion);
            else
            System.out.println("Error al conectarse");

        } //fin clase
} // fin main