package UTN.Conexion;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLDataException;
import java.sql.SQLException;

public class conexion {
    public static Connection getConnection() {
        Connection conexion = null;
        //variables para conectarnos a la base de datos
        var baseDatos = "estudiantes2022;
        var url = "jdvc:mysql://localhost:3306/" + baseDatos;
        var usuario = "root";
        var password = "admin";

        //cargamos la clase del driver de mysql en memoria
        try {
            Class.forName("com.mysql.cj.jdbc.driver");
            conexion = DriverManager.getConnection(url, usuario, password);


        } catch (ClassNotFoundException | SQLException e){
            System.out.println("ocurrrio un error en la conexion: "+ e.getMessage());
        }//fin catch
        return conexion;
    }//fin metodo connection
}